#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━#

lMl10l = "˛ Jep ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . ."            #ساد
sad = "https://telegra.ph/file/4a59106d0ade82859136b.mp4"
sad2 = "https://telegra.ph/file/6e6f59bac38be6b983f56.mp4"
sad3 = "https://telegra.ph/file/fa1d3bf72e1f7a1e08474.mp4"
sad4 = "https://telegra.ph/file/890a01ea6cb065a7faa42.mp4"
sad5 = "https://telegra.ph/file/66778d145442699ce6038.mp4"
sad6 = "https://telegra.ph/file/50d9d6481803e21a30716.mp4"
sad7 = "https://telegra.ph/file/f79a31446027f741715a8.mp4"
sad8 = "https://telegra.ph/file/d1face4210bb7a883fdef.mp4"
sad9 = "https://telegra.ph/file/edf483bb182e4e328c5d4.mp4"

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━#

ROZA = "˛ Jep ، ٰ𝖦𝗂𝖿 CْuٌTِeَ ."            #كيوت
cute = "https://telegra.ph/file/bf2d2cb360b0bc05dd7c2.mp4"
cute2 = "https://telegra.ph/file/17c92862ca1283914a91f.mp4"
cute3 = "https://telegra.ph/file/89dc704a356b4b0f6fe89.mp4"
cute4 = "https://telegra.ph/file/cf43d80cd5bbe0fdf3b5a.mp4"
cute5 = "https://telegra.ph/file/8c9d1d7c1368631e9178b.mp4"
cute6 = "https://telegra.ph/file/f67f3c36091543134bfe3.mp4"
cute7 = "https://telegra.ph/file/490a014e0e4974bfe94d5.mp4"
cute8 = "https://telegra.ph/file/ed1d5b4fa2e86e6d7f96f.mp4"
cute9 = "https://telegra.ph/file/a66b32e8f831ed74ca950.mp4"

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━#
